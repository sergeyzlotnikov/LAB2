// ссылка на блок веб-страницы, в котором будет отображаться графика
var container;

// переменные: камера, сцена и отрисовщик
var camera, scene, renderer;

// в этой функции можно добавлять объекты и выполнять их первичную настройку
function init() 
{
    // получение ссылки на блок html-страницы
    container = document.getElementById('container');
    // создание сцены
    scene = new THREE.Scene();

    // установка параметров камеры
    // 45 - угол обзора
    // window.innerWidth / window.innerHeight - соотношение сторон
    // 1 и 4000 - ближняя и дальняя плоскости отсечения
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 4000);    

    // установка позиции камеры
    camera.position.set(0, 30, 30);
    
    // установка точки, на которую камера будет смотреть
    camera.lookAt(new THREE.Vector3(0, 0, 0));  

    // создание отрисовщика
    renderer = new THREE.WebGLRenderer( { antialias: false } );
    renderer.setSize(window.innerWidth, window.innerHeight);
    
	// закрашивание экрана синим цветом, заданным в шестнадцатеричной системе
    renderer.setClearColor(new THREE.Color(0.5,0.5,0.5), 1);

    container.appendChild(renderer.domElement);

    // добавление обработчика события изменения размеров окна
    window.addEventListener('resize', onWindowResize, false);
}

function onWindowResize() 
{
    // изменение соотношения сторон для виртуальной камеры
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    
	// изменение соотношения сторон рендера
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// в этой функции можно изменять параметры объектов и обрабатывать действия пользователя
function animate() 
{
    // сколько прошло времени
    let dt = clock.getDelta()
    
    // изменяем положение планеты
    for(let i = 0; i < planets.length - 1; i++) {
     
        // угла
        planets[i].angle += planets[i].speed * dt;
        if(planets[i].angle >= 360 || planets[i].angle <= -360){
            planets[i].angle = 0;
        }
    
        // координат
        let r = planets[0].pos.distanceTo(planets[i].pos)
        planets[i].pos.x = r * Math.cos(planets[i].angle * 3.14 / 180)
        planets[i].pos.z = r * Math.sin(planets[i].angle * 3.14 / 180)
        planets[i].sphere.position.copy(planets[i].pos)
        planets[i].sphere.rotation.y = planets[i].angle * 3.14 / 180
    }

    // просчет позиции и угла для луны
    // угла
    let j = planets.length - 1
    planets[j].angle += planets[j].speed * dt;
    if(planets[j].angle >= 360 || planets[j].angle <= -360){
        planets[j].angle = 0;
    }

    // координат
    planets[j].pos.x = planets[3].pos.x + 2 * Math.cos(planets[j].angle * 3.14 / 180)
    planets[j].pos.z = planets[3].pos.z + 2 * Math.sin(planets[j].angle * 3.14 / 180)
    planets[j].sphere.position.copy(planets[j].pos)
    planets[j].sphere.rotation.y = planets[j].angle * 3.14 / 180

    // режим слежения
    if (keyboard.pressed("0")) {
        
        // общий вид
        check = 0
    }
    if(keyboard.pressed("1")) {

        // меркурий
        check = 1
    }
    if(keyboard.pressed("2")) {

        // венера
        check = 2
    }
    if(keyboard.pressed("3")) {
        
        // земля
        check = 3
    }
    if(keyboard.pressed("4")) {
        
        // марс
        check = 4
    }

    // смена позиции камеры
    if(check == 0) {
        camera.position.set(0, 30, 30);
        camera.lookAt(new THREE.Vector3(0, 0, 0));
    }
    else {
        camera.position.set(planets[check].pos.x - 6, 5, planets[check].pos.z - 6);
        camera.lookAt(planets[check].pos);
    }

    // добавление функции на вызов при перерисовке браузером страницы 
    requestAnimationFrame(animate);
    render();
}

function render()
{
    // рисование кадра
    renderer.render(scene, camera);
}

// создание планеты
function getPlanet(tex_path, bump_path, r, x0, speed) {
    let planet = {};
    let geometry = new THREE.SphereGeometry(r, 32, 32);
    let tex = loader.load(tex_path);
    let material = null;
    if(bump_path != "") {
        let bump = loader.load(bump_path);
        material = new THREE.MeshPhongMaterial({
            map: tex,
            bumpMap: bump,
            bumpScale: 0.5,
            side: THREE.DoubleSide
        });
    }
    else {
        material = new THREE.MeshBasicMaterial({
            map: tex,
            side: THREE.DoubleSide
        });
    }
    planet.sphere = new THREE.Mesh(geometry, material);
    planet.pos = new THREE.Vector3(x0, 0, 0);
    planet.angle = 0
    planet.speed = speed
    return planet;
}

//отрисовка линии объекта
function drawLine(r) {

    // создаем примитив
    var lineGeometry = new THREE.Geometry();
    var vertices = lineGeometry.vertices;

    // отмечаем сегменты
    for(let i = 0; i < 360; i++) {
        let x = r * Math.cos(i * 3.14 / 180)
        let z = r * Math.sin(i * 3.14 / 180)
        vertices.push(new THREE.Vector3(x, 0, z));
    }
        
    // параметры: цвет, размер черты, размер промежутка
    var lineMaterial = new THREE.LineDashedMaterial({
        color: new THREE.Color(1, 1, 0),
        dashSize: 1,
        gapSize: 1 
    });
    var line = new THREE.Line(lineGeometry, lineMaterial);
    line.computeLineDistances();
    scene.add(line);
}

// функция инициализации камеры, отрисовщика, объектов сцены и т.д.
init();

// создание геометрии для сферы	
var geometry = new THREE.SphereGeometry(64, 32, 32);

// создание загрузчика текстур
var loader = new THREE.TextureLoader();

// загрузка текстуры
var tex = loader.load("planets/starmap.jpg");

// создание материала
var material = new THREE.MeshBasicMaterial({
    map: tex,
    side: THREE.DoubleSide
});

// создание объекта
var sphere = new THREE.Mesh(geometry, material);

// размещение объекта в сцене
scene.add(sphere);

// создание массива планет    
var planets = [];

// солнце
var sun = getPlanet("planets/sunmap.jpg", "", 1.5, 0, 10)
planets.push(sun);

// меркурий
var mercury = getPlanet("planets/mercury/mercurymap.jpg", "planets/mercury/mercurybump.jpg", 0.3, 3, 60)
drawLine(sun.pos.distanceTo(mercury.pos))
planets.push(mercury);

// венера
var venus = getPlanet("planets/venus/venusmap.jpg", "planets/venus/venusbump.jpg", 0.6, 6, 40)
drawLine(sun.pos.distanceTo(venus.pos))
planets.push(venus)

// земля
var earth = getPlanet("planets/earth/earthmap1k.jpg", "planets/earth/earthbump1k.jpg", 1, 10, 30)
drawLine(sun.pos.distanceTo(earth.pos))
planets.push(earth)

//марс
var mars = getPlanet("planets/mars/marsmap1k.jpg", "planets/mars/marsbump1k.jpg", 0.7, 15, 35)
drawLine(sun.pos.distanceTo(mars.pos))
planets.push(mars)

// луна - спутник земли
var moon = getPlanet("planets/earth/moon/moonmap1k.jpg", "planets/earth/moon/moonbump1k.jpg", 0.2, 12, 50)
planets.push(moon)

// перебор планет
for (var i = 0; i < planets.length; i++) 
{
    // действие
    planets[i].sphere.position.copy(planets[i].pos)
    scene.add(planets[i].sphere)
}

// создание точечного источника освещения заданного цвета
var spotlight = new THREE.PointLight(new THREE.Color(1, 1, 1));

// установка позиции источника освещения
spotlight.position.set(20, 20, 20);

// добавление источника в сцену
scene.add(spotlight);

// нажатие клавиш
var keyboard = new THREEx.KeyboardState();

// время
var clock = new THREE.Clock();

// наблюдатель
var check = false

// обновление данных по таймеру браузера
animate();